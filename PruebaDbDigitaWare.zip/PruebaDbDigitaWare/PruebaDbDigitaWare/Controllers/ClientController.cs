﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PruebaDbDigitaWare.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaDbDigitaWare.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ClientController : ControllerBase
    {
        private readonly billsCTX ctx;
        public ClientController(billsCTX _ctx)
        {
            ctx = _ctx;
        }
        [HttpGet]
        public async Task<List<Client>> GetAllClients()
        {
            return await ctx.Client.ToListAsync();
        }

        // GET: api/Client/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Client>> GetClient(int id)
        {
            var client = await ctx.Client.FindAsync(id);

            if (client == null)
            {
                return NotFound();
            }

            return client;
        }

        [HttpPost]
        public async Task<ActionResult<Client>> PostClient(Client client)
        {
            ctx.Client.Add(client);
            await ctx.SaveChangesAsync();

            return CreatedAtAction("GetProduct", new { id = client.ClientId }, client);
        }


    }
}
