﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PruebaDbDigitaWare.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaDbDigitaWare.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SaleController : ControllerBase
    {


        private readonly billsCTX ctx;


        public SaleController(billsCTX _ctx)
        {
            ctx = _ctx;
        }
        [HttpGet]
        public async Task<List<Sale>> GetAllSale()
        {
            return await ctx.Sale.Include(x => x.Client).Include(x => x.Product).ToListAsync();
        }

        // GET: api/Sale/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Sale>> GetSale(int id)
        {
            var sale = await ctx.Sale.FindAsync(id);

            if (sale == null)
            {
                return NotFound();
            }

            return sale;
        }

        [HttpPost]
        public async Task<ActionResult<Sale>> PostInventary(Sale sale)
        {
            ctx.Sale.Add(sale);
            await ctx.SaveChangesAsync();

            return Ok();
        }
    }
}
