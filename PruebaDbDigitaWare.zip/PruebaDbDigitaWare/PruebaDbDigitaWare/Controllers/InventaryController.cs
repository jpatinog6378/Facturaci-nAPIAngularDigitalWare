﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PruebaDbDigitaWare.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaDbDigitaWare.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class InventaryController : ControllerBase
    {
        private readonly billsCTX ctx;


        public InventaryController(billsCTX _ctx)
        {
            ctx = _ctx;
        }
        [HttpGet]
        public async Task<List<Inventary>> GetAllInventary()
        {
            return await ctx.Inventary.ToListAsync();
        }

        // GET: api/Inventary/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Inventary>> GetInventary(int id)
        {
            var inventary = await ctx.Inventary.FindAsync(id);

            if (inventary == null)
            {
                return NotFound();
            }

            return inventary;
        }

        [HttpPost]
        public async Task<ActionResult<Inventary>> PostInventary(Inventary inventary)
        {
            ctx.Inventary.Add(inventary);
            await ctx.SaveChangesAsync();

            return CreatedAtAction("GetProduct", new { id = inventary.InventaryId }, inventary);
        }
    }
}
