﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace PruebaDbDigitaWare.Models
{
    public partial class Product
    {
        public Product()
        {
            Inventary = new HashSet<Inventary>();
            Sale = new HashSet<Sale>();
        }

        public int ProductId { get; set; }
        public string Name { get; set; }
        public string Brand { get; set; }
        public decimal Price { get; set; }

        public virtual ICollection<Inventary> Inventary { get; set; }
        public virtual ICollection<Sale> Sale { get; set; }
    }
}
