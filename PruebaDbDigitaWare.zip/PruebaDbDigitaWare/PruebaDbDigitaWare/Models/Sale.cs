﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace PruebaDbDigitaWare.Models
{
    public partial class Sale
    {
        public int SaleId { get; set; }
        public DateTime SellDate { get; set; }
        public int? QuantitySell { get; set; }
        public int? ProductId { get; set; }
        public int? ClientId { get; set; }

        public  Client Client { get; set; }
        public  Product Product { get; set; }
    }
}
