﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace PruebaDbDigitaWare.Models
{
    public partial class billsCTX : DbContext
    {
        public billsCTX()
        {
        }

        public billsCTX(DbContextOptions<billsCTX> options)
            : base(options)
        {
        }

        public virtual DbSet<Client> Client { get; set; }
        public virtual DbSet<Inventary> Inventary { get; set; }
        public virtual DbSet<Product> Product { get; set; }
        public virtual DbSet<Sale> Sale { get; set; }

    

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Client>(entity =>
            {
                entity.ToTable("CLIENT");

                entity.Property(e => e.ClientId).HasColumnName("client_id");

                entity.Property(e => e.DocumentNumber).HasColumnName("document_number");

                entity.Property(e => e.DocumentType)
                    .IsRequired()
                    .HasColumnName("document_type")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasColumnName("first_name")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasColumnName("last_name")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Inventary>(entity =>
            {
                entity.ToTable("INVENTARY");

                entity.Property(e => e.InventaryId).HasColumnName("inventary_id");

                entity.Property(e => e.ProductId).HasColumnName("product_id");

                entity.Property(e => e.Quantity).HasColumnName("quantity");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.Inventary)
                    .HasForeignKey(d => d.ProductId)
                    .HasConstraintName("FK__INVENTARY__produ__286302EC");
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.ToTable("PRODUCT");

                entity.Property(e => e.ProductId).HasColumnName("product_id");

                entity.Property(e => e.Brand)
                    .IsRequired()
                    .HasColumnName("brand")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Price)
                    .HasColumnName("price")
                    .HasColumnType("decimal(18, 3)");
            });

            modelBuilder.Entity<Sale>(entity =>
            {
                entity.ToTable("SALE");

                entity.Property(e => e.SaleId).HasColumnName("sale_id");

                entity.Property(e => e.ClientId).HasColumnName("client_id");

                entity.Property(e => e.ProductId).HasColumnName("product_id");

                entity.Property(e => e.QuantitySell).HasColumnName("quantity_sell");

                entity.Property(e => e.SellDate)
                    .HasColumnName("sell_date")
                    .HasColumnType("date");

                entity.HasOne(d => d.Client)
                    .WithMany(p => p.Sale)
                    .HasForeignKey(d => d.ClientId)
                    .HasConstraintName("FK__SALE__client_id__2C3393D0");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.Sale)
                    .HasForeignKey(d => d.ProductId)
                    .HasConstraintName("FK__SALE__product_id__2B3F6F97");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
